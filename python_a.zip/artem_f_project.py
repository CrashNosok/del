from tkinter import *
from PIL import ImageTk, Image

'''
1) В самом начале приветствие с кнопкой "начать"
2) 
'''

class Coffemachine:
    def __init__(self):
        self.name = ''
        self.count_water = 0
        self.count_caffe = 0
        self.path = './photoes/coffee_shop.jpg'

    def start(self):
        self.path = './photoes/sorts.jpg'
    
    def make_capuchino(self):
        self.path = './photoes/capuchino.jpg'

    def make_americano(self):
        self.path = './photoes/americano.jpg'
    
    def make_latte(self):
        self.path = './photoes/latte.jpg'
    
    def make_espresso(self):
        self.path = './photoes/espresso.jpg'


def capuchino():
    global root

    root.destroy()
    root = Tk()
    coffemachine.make_capuchino()
    img = ImageTk.PhotoImage(Image.open(coffemachine.path))
    panel = Label(root, image = img)
    panel.grid(row=0, columnspan=2)

    lab = Label(root, text='Ваш капучино готов!', font='Arial 25', fg='green')
    lab.grid(row=1, columnspan=2)

    but = Button(root, text='Вернуться назад', font='Arial 16', width=17)
    but.bind('<Button-1>', start)
    but.grid(row=2, columnspan=2)
    root.mainloop()

def americano():
    global root

    root.destroy()
    root = Tk()
    coffemachine.make_americano()
    img = ImageTk.PhotoImage(Image.open(coffemachine.path))
    panel = Label(root, image = img)
    panel.grid(row=0, columnspan=2)

    lab = Label(root, text='Ваш американо готов!', font='Arial 25', fg='green')
    lab.grid(row=1, columnspan=2)

    but = Button(root, text='Вернуться назад', font='Arial 16', width=17)
    but.bind('<Button-1>', start)
    but.grid(row=2, columnspan=2)
    root.mainloop()


def latte():
    global root

    root.destroy()
    root = Tk()
    coffemachine.make_latte()
    img = ImageTk.PhotoImage(Image.open(coffemachine.path))
    panel = Label(root, image = img)
    panel.grid(row=0, columnspan=2)

    lab = Label(root, text='Ваш латте готов!', font='Arial 25', fg='green')
    lab.grid(row=1, columnspan=2)

    but = Button(root, text='Вернуться назад', font='Arial 16', width=17)
    but.bind('<Button-1>', start)
    but.grid(row=2, columnspan=2)
    root.mainloop()


def espresso():
    global root

    root.destroy()
    root = Tk()
    coffemachine.make_espresso()
    img = ImageTk.PhotoImage(Image.open(coffemachine.path))
    panel = Label(root, image = img)
    panel.grid(row=0, columnspan=2)

    lab = Label(root, text='Ваш еспрессо готов!', font='Arial 25', fg='green')
    lab.grid(row=1, columnspan=2)

    but = Button(root, text='Вернуться назад', font='Arial 16', width=17)
    but.bind('<Button-1>', start)
    but.grid(row=2, columnspan=2)
    root.mainloop()

def start(event):
    global root

    root.destroy()
    root = Tk()
    coffemachine.start()
    img = ImageTk.PhotoImage(Image.open(coffemachine.path))
    panel = Label(root, image = img)
    panel.grid(row=0, columnspan=2)
    but1 = Button(root, text = 'Капучино', height=2, width=25, command=capuchino)
    but2 = Button(root, text = 'Американо', height=2, width=25, command=americano)
    but3 = Button(root, text = 'Латте', height=2, width=25, command=latte)
    but4 = Button(root, text = 'Эспрессо', height=2, width=25, command=espresso)
    but1.grid(row=1, column=0)
    but2.grid(row=1, column=1)
    but3.grid(row=2, column=0)
    but4.grid(row=2, column=1)


    root.mainloop()


root = Tk()
coffemachine = Coffemachine()

img = ImageTk.PhotoImage(Image.open(coffemachine.path))
panel = Label(root, image = img)
panel.grid(row=0, columnspan=2)

but = Button(root, text='start', height=3, width=17, font='Arial 27', fg='green')
but.bind('<Button-1>', start)
but.grid(row=1, column=0)

root.mainloop()
